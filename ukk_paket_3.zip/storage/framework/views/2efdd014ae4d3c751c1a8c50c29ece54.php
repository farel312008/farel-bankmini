<!DOCTYPE html>
<html lang="id">
<body>
    <h2>Pemulihan Akun Bank Mini</h2>
    <p>Gunakan kode OTP berikut untuk mengganti <?php echo e($credentialName); ?> Anda:</p>
    <p style="font-size: 24px; font-weight: bold; letter-spacing: 6px;"><?php echo e($otp); ?></p>
    <p>Kode berlaku selama 10 menit dan hanya dapat digunakan satu kali. Jangan bagikan kode ini kepada siapa pun.</p>
    <p>Jika Anda tidak meminta perubahan ini, abaikan email ini.</p>
</body>
</html>
<?php /**PATH C:\laragon\www\UKK_PAKET_1\UKK_PAKET_3\ukk_paket_3\resources\views/emails/credential-reset-otp.blade.php ENDPATH**/ ?>